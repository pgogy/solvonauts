<?php 
 include '/home/pgogywe1/public_html/solved/harvest/standard_ingest.php';
 include '/home/pgogywe1/public_html/solved/harvest/slidesharescripts/slideshare_ingest.php';
 $slideshare_ingest = new slideshare_ingest(); $slideshare_ingest->slideshare_search('OpenEducationEdinburgh','CC-BY');
?>