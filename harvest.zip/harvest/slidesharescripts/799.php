<?php 
 include '../standard_harvest.php';
 include 'slideshare_ingest.php';
 $slideshare_ingest = new slideshare_ingest(); $slideshare_ingest->slideshare_search('OpenEducationEdinburgh','CC-BY');
?>