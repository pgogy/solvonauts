<?php 
 include '/home/pgogywe1/public_html/solved/harvest/standard_ingest.php';
 include '/home/pgogywe1/public_html/solved/harvest/tesscripts/tes_ingest.php';
 $tes_ingest = new tes_ingest(); $youtube_ingest->get_url('http://tes.com','http://www.tes.com/resources/search/?authorId=20008719','CC-BY');
?>