<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('https://ocw.mit.edu/courses/brain-and-cognitive-sciences/9-20-animal-behavior-fall-2005/audio-lectures/rss.xml ', '442');
 $xml_ingest->xml_process('','442','https://ocw.mit.edu/courses/brain-and-cognitive-sciences/9-20-animal-behavior-fall-2005/audio-lectures/rss.xml ');
?>