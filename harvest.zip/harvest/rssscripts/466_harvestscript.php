<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('https://ocw.mit.edu/courses/linguistics-and-philosophy/24-213-philosophy-of-film-fall-2004/video-lectures/rss.xml ', '466');
 $xml_ingest->xml_process('','466','https://ocw.mit.edu/courses/linguistics-and-philosophy/24-213-philosophy-of-film-fall-2004/video-lectures/rss.xml ');
?>