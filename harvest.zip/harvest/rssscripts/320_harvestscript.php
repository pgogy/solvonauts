<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('http://ocw.usu.edu/economics/index-rss_recent', '320');
 $xml_ingest->xml_process('http://creativecommons.org/licenses/by-nc-sa/2.5/','320','http://ocw.usu.edu/economics/index-rss_recent');
?>