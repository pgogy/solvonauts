<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('http://roboticscourseware.org/3-robotics-pedagogy-bibliography/@@rss', '766');
 $xml_ingest->xml_process('','766','http://roboticscourseware.org/3-robotics-pedagogy-bibliography/@@rss');
?>