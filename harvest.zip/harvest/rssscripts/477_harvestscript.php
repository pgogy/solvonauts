<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('https://ocw.mit.edu/courses/mechanical-engineering/2-830j-control-of-manufacturing-processes-sma-6303-spring-2008/video-lectures/rss.xml', '477');
 $xml_ingest->xml_process('','477','https://ocw.mit.edu/courses/mechanical-engineering/2-830j-control-of-manufacturing-processes-sma-6303-spring-2008/video-lectures/rss.xml');
?>