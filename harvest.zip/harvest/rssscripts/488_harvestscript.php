<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('http://open.conted.ox.ac.uk/taxonomy/term/1555/all/feed', '488');
 $xml_ingest->xml_process('Creative Commons Attribution-NonCommercial-ShareAlike','488','http://open.conted.ox.ac.uk/taxonomy/term/1555/all/feed');
?>