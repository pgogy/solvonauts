<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('https://ocw.mit.edu/rss/all/mit-allcourses-4.xml', '158');
 $xml_ingest->xml_process('','158','https://ocw.mit.edu/rss/all/mit-allcourses-4.xml');
?>