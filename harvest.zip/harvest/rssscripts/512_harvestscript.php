<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('https://ocw.mit.edu/rss/all/mit-allcourses-21W.xml', '512');
 $xml_ingest->xml_process('','512','https://ocw.mit.edu/rss/all/mit-allcourses-21W.xml');
?>