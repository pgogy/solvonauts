<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('http://ocw.lms.athabascau.ca', '191');
 $xml_ingest->xml_process('','191','http://ocw.lms.athabascau.ca');
?>