<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('http://www.kocw.net/home/rss/engineeringRss.xml', '1751');
 $xml_ingest->xml_process('','1751','http://www.kocw.net/home/rss/engineeringRss.xml');
?>