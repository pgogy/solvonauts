<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('http://api.flickr.com/services/feeds/photos_public.gne?id=41815917@N06&amp;lang=en-us&amp;format=rss_200', '348');
 $xml_ingest->xml_process('No known copyright restrictions','348','http://api.flickr.com/services/feeds/photos_public.gne?id=41815917@N06&amp;lang=en-us&amp;format=rss_200');
?>