<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('https://ocw.mit.edu/courses/global-studies-and-languages/21f-223-listening-speaking-and-pronunciation-fall-2004/video-lectures/rss.xml', '565');
 $xml_ingest->xml_process('','565','https://ocw.mit.edu/courses/global-studies-and-languages/21f-223-listening-speaking-and-pronunciation-fall-2004/video-lectures/rss.xml');
?>