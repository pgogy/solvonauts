<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('http://ocw.kyoto-u.ac.jp/en/24-graduate-school-of-informatics/@@rss', '575');
 $xml_ingest->xml_process('','575','http://ocw.kyoto-u.ac.jp/en/24-graduate-school-of-informatics/@@rss');
?>