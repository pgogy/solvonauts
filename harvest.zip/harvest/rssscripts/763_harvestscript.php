<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('http://roboticscourseware.org/rss', '763');
 $xml_ingest->xml_process('','763','http://roboticscourseware.org/rss');
?>