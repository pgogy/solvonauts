<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('http://ocf.kfupm.edu.sa/rss/CHEM/Chemistry.xml', '601');
 $xml_ingest->xml_process('http://creativecommons.org/licenses/by-nc-sa/3.0/us/','601','http://ocf.kfupm.edu.sa/rss/CHEM/Chemistry.xml');
?>