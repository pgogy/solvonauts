<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('http://ocw.unican.es/ciencias-sociales-y-juridicas/rss', '262');
 $xml_ingest->xml_process('','262','http://ocw.unican.es/ciencias-sociales-y-juridicas/rss');
?>