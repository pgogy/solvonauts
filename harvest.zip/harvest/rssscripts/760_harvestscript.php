<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('http://www.uhu.es/sevirtual/ocw/rss/', '760');
 $xml_ingest->xml_process('','760','http://www.uhu.es/sevirtual/ocw/rss/');
?>