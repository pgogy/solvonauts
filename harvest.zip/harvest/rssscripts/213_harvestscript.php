<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('http://edunetworks.ugr.es/ocw/file.php/1/opencoursewareugr.xml', '213');
 $xml_ingest->xml_process('','213','http://edunetworks.ugr.es/ocw/file.php/1/opencoursewareugr.xml');
?>