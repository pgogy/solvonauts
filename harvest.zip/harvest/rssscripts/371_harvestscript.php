<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('http://api.flickr.com/services/feeds/photos_public.gne?id=36038586@N04&amp;lang=en-us&amp;format=rss_200', '371');
 $xml_ingest->xml_process('No known copyright restrictions','371','http://api.flickr.com/services/feeds/photos_public.gne?id=36038586@N04&amp;lang=en-us&amp;format=rss_200');
?>