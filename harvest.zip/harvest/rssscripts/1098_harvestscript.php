<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('http://mediapub.it.ox.ac.uk/feeds/129177/video.xml', '1098');
 $xml_ingest->xml_process('','1098','http://mediapub.it.ox.ac.uk/feeds/129177/video.xml');
?>