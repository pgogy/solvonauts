<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('http://www.opener.ou.nl/front-page/rss', '35');
 $xml_ingest->xml_process('','35','http://www.opener.ou.nl/front-page/rss');
?>