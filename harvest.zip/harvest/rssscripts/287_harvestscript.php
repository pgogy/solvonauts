<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('http://ocw.ub.edu/enginyeria-tecnica-dinformatica-de-sistemes/rss_recent', '287');
 $xml_ingest->xml_process('','287','http://ocw.ub.edu/enginyeria-tecnica-dinformatica-de-sistemes/rss_recent');
?>