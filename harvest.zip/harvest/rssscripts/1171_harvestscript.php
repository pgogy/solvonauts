<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('http://mediapub.it.ox.ac.uk/feeds/129034/video.xml', '1171');
 $xml_ingest->xml_process('','1171','http://mediapub.it.ox.ac.uk/feeds/129034/video.xml');
?>