<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('http://ocw.bib.upct.es/rss/rss_ocw.xml', '41');
 $xml_ingest->xml_process('','41','http://ocw.bib.upct.es/rss/rss_ocw.xml');
?>