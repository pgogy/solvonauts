<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('http://ocw.kyoto-u.ac.jp/ja/field-science-education-and-research-center/@@rss', '781');
 $xml_ingest->xml_process('http://creativecommons.org/licenses/by-nc-sa/3.0/','781','http://ocw.kyoto-u.ac.jp/ja/field-science-education-and-research-center/@@rss');
?>