<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('http://ocw.uniovi.es/rss/file.php/rss.xml', '64');
 $xml_ingest->xml_process('','64','http://ocw.uniovi.es/rss/file.php/rss.xml');
?>