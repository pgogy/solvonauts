<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('http://mediapub.it.ox.ac.uk/feeds/129235/audio.xml', '971');
 $xml_ingest->xml_process('','971','http://mediapub.it.ox.ac.uk/feeds/129235/audio.xml');
?>