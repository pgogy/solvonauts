<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('http://artsone-open.arts.ubc.ca/category/lecture/feed/', '1638');
 $xml_ingest->xml_process('http://creativecommons.org/licenses/by-nc/2.5/ca/deed.en_US','1638','http://artsone-open.arts.ubc.ca/category/lecture/feed/');
?>