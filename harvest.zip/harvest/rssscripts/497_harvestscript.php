<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('https://ocw.mit.edu/rss/all/mit-allcourses-8.xml', '497');
 $xml_ingest->xml_process('','497','https://ocw.mit.edu/rss/all/mit-allcourses-8.xml');
?>