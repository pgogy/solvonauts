<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('http://ocw.umb.edu/critical-reading-and-writing/@@rss', '607');
 $xml_ingest->xml_process('','607','http://ocw.umb.edu/critical-reading-and-writing/@@rss');
?>