<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('http://ocwus.us.es/ingenieria-de-sistemas-y-automatica/rss', '725');
 $xml_ingest->xml_process('','725','http://ocwus.us.es/ingenieria-de-sistemas-y-automatica/rss');
?>