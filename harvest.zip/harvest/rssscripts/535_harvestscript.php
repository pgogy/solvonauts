<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('https://ocw.mit.edu/rss/all/mit-allpersiancourses.xml', '535');
 $xml_ingest->xml_process('','535','https://ocw.mit.edu/rss/all/mit-allpersiancourses.xml');
?>