<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('http://www.ocw.unc.edu.ar/rss', '762');
 $xml_ingest->xml_process('http://creativecommons.org/licenses/by-nc-sa/2.5/ar/','762','http://www.ocw.unc.edu.ar/rss');
?>