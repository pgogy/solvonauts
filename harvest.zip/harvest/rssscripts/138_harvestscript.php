<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('http://api.flickr.com/services/feeds/photos_public.gne?id=41639353@N08&format=rss_200_enc', '138');
 $xml_ingest->xml_process('No known copyright restrictions','138','http://api.flickr.com/services/feeds/photos_public.gne?id=41639353@N08&format=rss_200_enc');
?>