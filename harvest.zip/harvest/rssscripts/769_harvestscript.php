<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('http://ocw.kyoto-u.ac.jp/ja/28.5/@@rss', '769');
 $xml_ingest->xml_process('http://creativecommons.org/licenses/by-nc-sa/3.0/','769','http://ocw.kyoto-u.ac.jp/ja/28.5/@@rss');
?>