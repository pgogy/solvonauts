<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('http://www.kocw.net/en/rss/Pedagogy_en.xml', '150');
 $xml_ingest->xml_process('http://creativecommons.org/licenses/by-nc-nd/2.0/kr/','150','http://www.kocw.net/en/rss/Pedagogy_en.xml');
?>