<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('http://www.bodleian.ox.ac.uk/news/rss.xml', '1208');
 $xml_ingest->xml_process('','1208','http://www.bodleian.ox.ac.uk/news/rss.xml');
?>