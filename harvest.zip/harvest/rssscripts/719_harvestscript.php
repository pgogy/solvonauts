<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('http://ocwus.us.es/historia-de-america/rss', '719');
 $xml_ingest->xml_process('','719','http://ocwus.us.es/historia-de-america/rss');
?>