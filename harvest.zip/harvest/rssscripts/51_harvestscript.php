<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('http://e-ujier.uji.es/pls/www/!gri_www.euji22108', '51');
 $xml_ingest->xml_process('','51','http://e-ujier.uji.es/pls/www/!gri_www.euji22108');
?>