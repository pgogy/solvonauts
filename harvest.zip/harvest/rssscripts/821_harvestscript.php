<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('http://mediapub.it.ox.ac.uk/feeds/129189/video.xml', '821');
 $xml_ingest->xml_process('','821','http://mediapub.it.ox.ac.uk/feeds/129189/video.xml');
?>