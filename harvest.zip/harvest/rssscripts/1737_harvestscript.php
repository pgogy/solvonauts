<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('http://victimology.louisegrove.com/feed/', '1737');
 $xml_ingest->xml_process('https://creativecommons.org/licenses/by/4.0/','1737','http://victimology.louisegrove.com/feed/');
?>