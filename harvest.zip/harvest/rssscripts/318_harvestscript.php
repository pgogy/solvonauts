<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('http://ocw.usu.edu/biology/index-rss_recent', '318');
 $xml_ingest->xml_process('http://creativecommons.org/licenses/by-nc-sa/2.5/','318','http://ocw.usu.edu/biology/index-rss_recent');
?>