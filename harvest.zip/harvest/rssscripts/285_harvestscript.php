<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('http://ocw.ub.edu/enginyeria-electronica/rss_recent', '285');
 $xml_ingest->xml_process('','285','http://ocw.ub.edu/enginyeria-electronica/rss_recent');
?>