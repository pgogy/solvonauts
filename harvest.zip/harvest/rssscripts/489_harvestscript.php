<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('http://open.conted.ox.ac.uk/taxonomy/term/1566/all/feed', '489');
 $xml_ingest->xml_process('Public Domain/Out of Copyright','489','http://open.conted.ox.ac.uk/taxonomy/term/1566/all/feed');
?>