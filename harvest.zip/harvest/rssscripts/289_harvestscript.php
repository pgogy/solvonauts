<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('http://ocw.ub.edu/filologia-anglesa/rss_recent', '289');
 $xml_ingest->xml_process('','289','http://ocw.ub.edu/filologia-anglesa/rss_recent');
?>