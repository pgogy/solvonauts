<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('httpss://ocw.mit.edu/rss/new/mit-newcourses.xml', '1');
 $xml_ingest->xml_process('','1','httpss://ocw.mit.edu/rss/new/mit-newcourses.xml');
?>