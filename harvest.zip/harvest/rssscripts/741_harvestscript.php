<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('http://ocwus.us.es/psicologia-basica/rss', '741');
 $xml_ingest->xml_process('','741','http://ocwus.us.es/psicologia-basica/rss');
?>