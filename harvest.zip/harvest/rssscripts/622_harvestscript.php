<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('http://hanyangocw.hanyang.ac.kr/class/front-page/rss', '622');
 $xml_ingest->xml_process('','622','http://hanyangocw.hanyang.ac.kr/class/front-page/rss');
?>