<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('http://globalsocialtheory.org/category/thinkers/feed/', '1757');
 $xml_ingest->xml_process('https://creativecommons.org/licenses/by-nc-nd/3.0/','1757','http://globalsocialtheory.org/category/thinkers/feed/');
?>