<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/rssscripts/xml_ingest.php';
 $xml_ingest = new xml_ingest(); $xml_ingest->curl_data('http://globalsocialtheory.org/feed/', '1762');
 $xml_ingest->xml_process('https://creativecommons.org/licenses/by-nc-nd/3.0/','1762','http://globalsocialtheory.org/feed/');
?>