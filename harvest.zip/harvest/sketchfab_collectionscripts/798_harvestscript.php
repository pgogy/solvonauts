<?php 
 include '/home/pgogywe1/public_html/solved/harvest/standard_ingest.php';
 include '/home/pgogywe1/public_html/solved/harvest/sketchfab_collectionscripts/sketchfab_collection_ingest.php';
 $sketchfab_collection_ingest = new sketchfab_collection_ingest(); $sketchfab_collection_ingest->get_url('https://sketchfab.com/','https://sketchfab.com/openededinburgh/collections/the-royal-dick-school-of-veterinary-studies','');
?>