<?php 
 include '../standard_harvest.php';
 include 'sketchfab_collection_ingest.php';
 $sketchfab_ingest = new sketchfab_collection_ingest(); $sketchfab_collection_ingest->get_url('https://sketchfab.com/','https://sketchfab.com/openededinburgh/collections/the-royal-dick-school-of-veterinary-studies','');
?>