<?PHP

	define("DB_HOST","");
	define("DB_USERNAME_HARVEST","");
	define("DB_USERNAME_SEARCH","");
	define("DB_NAME","");
	define("DB_PASSWORD","");
	define("DB_TYPE","pdo");
	define("SITE_THEME","solvonauts");
	define("PAGINATION",25);
	define("LANGUAGE","en-gb");
	define("SITE","");
	
	//require_once(dirname(__FILE__) . "/" . "../public_html/site/site.php");
