<?php 
 include '/home/pgogywe1/public_html/solved/harvest/standard_ingest.php';
 include '/home/pgogywe1/public_html/solved/harvest/wiki_user_file_contribscripts/wiki_user_file_contrib_ingest.php';
 $wiki_user_file_contrib_ingest = new wiki_user_file_contrib_ingest(); $wiki_user_file_contrib_ingest->get_url('https://commons.wikimedia.org/','OpenEdEdinburgh','');
?>