<?php 
 include '/home/solvonau/public_html/harvest/standard_ingest.php';
 include '/home/solvonau/public_html/harvest/flickrscripts/flickr_ingest.php';
 $flickr_ingest = new flickr_ingest(); $flickr_ingest->flickr_search('Nottingham Vet School');
?>